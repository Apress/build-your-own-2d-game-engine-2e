/*
 * File: camera.js
 *
 * Encapsulates the user define WC and Viewport functionality
 */
"use strict";

import Camera from "./camera_xform.js";
export default Camera;