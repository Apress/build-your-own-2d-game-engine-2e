/* 
 * File: rigid_rectangle.js
 */
"use strict";

import RigidRectangle from "./rigid_rectangle_circle_collision.js";
export default RigidRectangle;
